# -*- coding: utf-8 -*-
# City, State и Status, Expired
# переделать общий словарь курьеров в список курьеров

import datetime
import json
import re
import time

import lxml.html
import mpu
import requests
import telebot
from bs4 import BeautifulSoup

from config import *

USERNAME_1 = "nordi"
PASSWORD_1 = "BVPmhE864A"
LOGIN_URL_1 = "https://arenaproject.it:31337"
PARSE_URL_1 = "https://arenaproject.it:31337/?a=glads"

USERNAME_2 = 'lucianovivaldi'
PASSWORD_2 = 'BVPmhE864A'
LOGIN_URL_2 = 'https://peresyloff.me/stuffer/login.php'
PARSE_URL_2 = "https://peresyloff.me/stuffer/drops.php"

USERNAME_3 = "lucianovivaldi"
PASSWORD_3 = "BVPmhE864Af"
LOGIN_URL_3 = "https://desertgun.club/stuffer/login.php"
PARSE_URL_3 = "https://desertgun.club/stuffer/drops.php"

couriers = []
zip_codes_4 = {}

bot = telebot.TeleBot(TELEGRAM_API_TOKEN)
content_types = [
    "text"
]

proxies = {
    'http': 'socks5h://localhost:9050',
    'https': 'socks5h://localhost:9050'
}


def initialization():
    global couriers
    global zip_codes_4

    with open("zip_codes_4.json", "r") as f:
        zip_codes_4 = json.load(f)

    parse_1()
    parse_2()
    parse_3()


def parse_1():
    global couriers

    # payload = {
    #     "login": USERNAME_1,
    #     "passw": PASSWORD_1
    # }
    # session_requests = requests.session()
    # result = session_requests.post(LOGIN_URL_1, data=payload, headers=dict(referer=LOGIN_URL_1), proxies=proxies)
    # print(result.status_code)
    # result = session_requests.get(PARSE_URL_1, headers=dict(referer=PARSE_URL_1), proxies=proxies)
    # with open("index_1.html", "w") as f:
    #     f.write(result.text)
    # print(result)
    # print(result.status_code)

    with open("index_1.html", "r") as f:
        contents = f.read()
        soup = BeautifulSoup(contents, 'lxml')

    for row in soup.select('tbody tr'):
        row_text = [x.text for x in row.find_all('td')]
        # print(row_text)
        try:
            zip_code_maybe = row_text[3]
            state_maybe = row_text[2]
            town_maybe = row_text[1]
            status = row_text[4][:2]
            res_1 = re.findall(r"\d{5}", zip_code_maybe)
            res_2 = re.findall(r"\D{2}", state_maybe)
            if len(res_1) != 1 or len(res_2) != 1:
                raise IndexError("wrong")
            zip_code_maybe_info = zip_codes_4[zip_code_maybe]
            if not zip_code_maybe_info:
                raise KeyError("not in database")
            if status == "Te":
                status = "Test"
                expired = "n/a"
            elif status == "Tr":
                status = "Training"
                expired = "n/a"
            elif status == "In":
                status = "In work"
                try:
                    expired = int(row_text[4][8:12])
                    if not expired:
                        raise ValueError
                    expired = row_text[4][8:18]
                except ValueError:
                    expired = "n/a"
            elif status == "No":
                status = "Not in work"
                expired = "n/a"
            else:
                status = "n/a"
                expired = "n/a"
            couriers.append(
                {
                    "zip_code": zip_code_maybe,
                    "state": state_maybe,
                    "town": town_maybe,
                    "status": status,
                    "expired": expired,
                    "service": "The arena",
                }
            )
        except IndexError:
            pass
        except KeyError:
            pass


def parse_2():
    global couriers

    # session = requests.session()
    # headers = {
    #     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36',
    #     "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    #     "accept-language": "ru,en;q=0.9",
    #     "cache-control": "max-age=0",
    #     "content-type": "application/x-www-form-urlencoded",
    #     "sec-fetch-dest": "document",
    #     "sec-fetch-mode": "navigate",
    #     "sec-fetch-site": "same-origin",
    #     "sec-fetch-user": "?1",
    #     "upgrade-insecure-requests": "1",
    #     'Connection': 'keep-alive',
    # }
    # data = session.get(LOGIN_URL_2, headers=headers)
    # page = lxml.html.fromstring(data.content)
    #
    # form = page.forms[0]
    # form.fields['login'] = USERNAME_2
    # form.fields['password'] = PASSWORD_2
    #
    # response = session.post(LOGIN_URL_2, data=form.form_values())
    # print(response.status_code)
    # response = session.get(PARSE_URL_2, headers=dict(referer=PARSE_URL_2))
    # with open("index_2.html", "w") as f:
    #     f.write(response.text)
    # print(response)
    # print(response.status_code)

    with open("index_2.html", "r") as f:
        contents = f.read()
        soup = BeautifulSoup(contents, 'lxml')

    for row in soup.select('tbody tr'):
        row_text = [x.text for x in row.find_all('td')]
        splitted = row_text[3][1:-18].split("\n")
        town = splitted[1]
        zip_code = splitted[3][:5]
        state = splitted[2][:2]
        expired = row_text[7][1:-1]
        status = row_text[5][1:-1]
        couriers.append(
            {
                "zip_code": zip_code,
                "state": state,
                "town": town,
                "status": status,
                "expired": expired,
                "service": "Peresyloff  aka Krass",
            }
        )


def parse_3():
    global couriers

    session = requests.session()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36',
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-language": "ru,en;q=0.9",
        "cache-control": "max-age=0",
        "content-type": "application/x-www-form-urlencoded",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        'Connection': 'keep-alive',
    }
    data = session.get(LOGIN_URL_3, headers=headers)
    page = lxml.html.fromstring(data.content)

    form = page.forms[0]
    form.fields['login'] = USERNAME_3
    form.fields['password'] = PASSWORD_3

    response = session.post(LOGIN_URL_3, data=form.form_values())
    print(response.status_code)
    response = session.get(PARSE_URL_3, headers=dict(referer=PARSE_URL_3))
    with open("index_3.html", "w") as f:
        f.write(response.text)
    print(response)
    print(response.status_code)

    with open("index_3.html", "r") as f:
        contents = f.read()
        soup = BeautifulSoup(contents, 'lxml')

    for row in soup.select('tbody tr')[1:]:
        try:
            row_text = [x.text for x in row.find_all('td')]
            town = row_text[1]
            state = row_text[2]
            zip_code = row_text[3]
            status = row_text[4]
            expired = row_text[5]
            couriers.append(
                {
                    "zip_code": zip_code,
                    "state": state,
                    "town": town,
                    "status": status,
                    "expired": expired,
                    "service": "AMG STUFF DROPS IN USA  aka Franklin",
                }
            )
        except IndexError:
            pass


def find_nearest_couriers(zip_code_sf):
    global couriers
    global zip_codes_4

    zip_codes_n_distances_list = []
    zip_codes_list = list(zip_codes_4)
    lat_1 = zip_codes_4[zip_code_sf]["lat"]
    lng_1 = zip_codes_4[zip_code_sf]["lng"]
    for zip_code in zip_codes_list:
        lat_2 = zip_codes_4[zip_code]["lat"]
        lng_2 = zip_codes_4[zip_code]["lng"]
        distance = mpu.haversine_distance((lat_1, lng_1), (lat_2, lng_2))
        zip_codes_n_distances_list.append(
            {
                "zip_code": zip_code,
                "distance": distance
            }
        )
    zip_codes_n_distances_list.sort(key=lambda x: x["distance"])
    nearest_couriers = []
    for zip_code_n_distance in zip_codes_n_distances_list:
        if len(nearest_couriers) == 20:
            break
        for courier in couriers:
            if courier["zip_code"] == zip_code_n_distance["zip_code"]:
                courier["distance"] = zip_code_n_distance["distance"]
                nearest_couriers.append(courier)

    return nearest_couriers


def bot_polling():
    while True:
        try:
            bot.polling(none_stop=True)
        except requests.exceptions.ReadTimeout:
            print(datetime.datetime.now(), "READ TIMEOUT ERROR, RECONNECTING")
            time.sleep(3)
        except requests.exceptions.ConnectionError:
            print(datetime.datetime.now(), "CONNECTION ERROR, RECONNECTING")
            time.sleep(3)


@bot.message_handler(func=lambda message: True, content_types=content_types)
def message_handler(message):
    global couriers

    print(datetime.datetime.now(), "MESSAGE", message.from_user.username, message.text)

    telegram_id = message.chat.id

    zip_code_maybe = re.findall(r"\d{5}", message.text)
    if len(zip_code_maybe) == 1 or len(message.text) != 5:
        try:
            user_zip_code = message.text
            user_zip_code_info = zip_codes_4[message.text]
            if not user_zip_code_info:
                raise KeyError

            nearest_couriers = find_nearest_couriers(user_zip_code)
            nearest_couriers_len = len(nearest_couriers)
            text = "<i>Ближайшие курьеры:</i>\n" \
                   "\n"
            for i in range(nearest_couriers_len):
                courier_info = nearest_couriers[i]

                text = text + f"{i + 1}. <code>{round(courier_info['distance'] * 0.621371, 1)} miles\n" \
                              f"Address: {courier_info['town']} | {courier_info['state']} | {courier_info['zip_code']}\n" \
                              f"Expired: {courier_info['expired']}\n" \
                              f"Status: {courier_info['status']}\n" \
                              f"Service: {courier_info['service']}</code>\n" \
                              f"\n"

                # text = f"{i + 1}. <code>{round(courier_info['distance'] * 0.621371, 1)} miles\n" \
                #        f"Address: {courier_info['town']} | {courier_info['state']} | {courier_info['zip_code']}\n" \
                #        f"Expired: {courier_info['expired']}\n" \
                #        f"Status: {courier_info['status']}\n" \
                #        f"Service: {courier_info['service']}</code>\n" \
                #        f"\n"
            bot.send_message(telegram_id, text=text, parse_mode="HTML")
        except KeyError:
            bot.send_message(telegram_id, text="Индекса нет в базе данных")
    else:
        bot.send_message(telegram_id, text="Это не почтовый индекс")


def main():
    initialization()
    print("let it burn")
    bot_polling()


if __name__ == '__main__':
    main()

