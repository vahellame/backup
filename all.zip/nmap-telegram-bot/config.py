# -*- coding: utf-8 -*-

REQUEST_KWARGS = {
    'proxy_url': 'socks5h://localhost:9050/',
    'urllib3_proxy_kwargs': {
        'assert_hostname': 'False',
        'cert_reqs': 'CERT_NONE'
    }
}

TELEGRAM_TOKEN = "1241005654:AAEQnwQ5teuJlYodwLyl4hof8JW6mv0pz80"
