# -*- coding: utf-8 -*-

import os
import vk_api

from vk_api.longpoll import VkLongPoll, VkEventType
from vk_api.utils import get_random_id

VK_TOKEN = "aca60f39b76af4c1f3a50f93116eed1a7c41330c5bea884149fce49027d5bb51b4d3be87028454a65f02e"
VK_ID_ROOT = 576604927

vk = vk_api.VkApi(token=VK_TOKEN)
longpoll = VkLongPoll(vk)

def send_message(user_id, message):
    vk.method('messages.send', {'user_id': user_id, 'message': message, "random_id": get_random_id()})


print("let it burn")

while True:
    try:
        for event in longpoll.listen():
            if event.type == VkEventType.MESSAGE_NEW and event.to_me and event.user_id == VK_ID_ROOT:
                if event.text == "out":
                    with open("out.txt", "r") as file:
                        logs = file.read()
                        if not logs:
                            send_message(VK_ID_ROOT, "<empty>")
                        else:
                            send_message(VK_ID_ROOT, logs)
                elif event.text == "errors":
                    with open("errors.txt", "r") as file:
                        logs = file.read()
                        if not logs:
                            send_message(VK_ID_ROOT, "<empty>")
                        else:
                            send_message(VK_ID_ROOT, logs)
                else:
                    os.system("{} > out.txt 2> errors.txt &".format(event.text))
    except:
        pass
