from flask import Flask, redirect
from flask_sslify import SSLify


app = Flask(__name__)

context = ('web.crt', 'web.key')
sslify = SSLify(app)

app = Flask(__name__)


@app.route('/')
def re():
    return redirect("https://vcard.is/vahellame", code=302)


if __name__ == "__main__":
    context = ('web.crt', 'web.key')
    app.run(host="0.0.0.0", port=443, ssl_context=context)
