nohup /home/walt/website/venv/bin/python /home/walt/website/app.py 1> /home/walt/website/output.txt 2> /home/walt/website/errors.txt &
