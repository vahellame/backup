POSTGRES_CONNECTION_PARAMS = {
    "dbname": "trello_vk_bot",
    "user": "postgres",
    "password": "21",
    "host": "localhost",
    "port": 5432
}

VK_API_TOKEN = "ae76dfa6a75671e5ea1158f10729e70a750983682df96a72b2aad181613dd21e407b9a6392533e3f5f85d"
VK_GROUP_ID = 195722017
